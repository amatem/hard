package net.ws3.hard;

import net.ws3.hard.levels.DemoLevel;
import net.ws3.hard.model.CircleWrapper;
import net.ws3.hard.screens.GameScreen;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.math.Circle;

public class HardGame extends Game {
	
	@Override
	public void create() {
		Assets.loadAssets();
		
		Circle circle = new Circle();
		circle.x = 1;
		circle.y = 1;
		circle.radius = 10;
		new CircleWrapper(circle, 0, 0);
		
		this.setScreen(new GameScreen(this, new DemoLevel()));
	}
	
	@Override
	public void render(){
		super.render();
	}
	
	@Override
	public void dispose(){
		Assets.dispose();
	}
}
