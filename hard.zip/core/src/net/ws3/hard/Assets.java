package net.ws3.hard;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.utils.TiledDrawable;

public class Assets {
	public static Texture bgTexture;
	public static Texture mapTileTexture;
	public static Texture mapNotPlainTexture;
	public static Texture mapWrapperTexture;
	public static Texture playerTexture;
	public static Texture blueCircleTexture;
	public static Texture yellowCircleTexture;
	
	public static TiledDrawable mapWrapperTiled;
	public static TiledDrawable mapTileTiled;
	public static TiledDrawable mapNotPlainTiled;
	
	public static void loadAssets(){
		bgTexture = new Texture(Gdx.files.internal("bg.png"));
		mapTileTexture = new Texture(Gdx.files.internal("mapTile.png"));
		mapNotPlainTexture = new Texture(Gdx.files.internal("mapNotPlain.png"));
		mapWrapperTexture = new Texture(Gdx.files.internal("mapWrapper.png"));
		playerTexture = new Texture(Gdx.files.internal("player.png"));
		blueCircleTexture = new Texture(Gdx.files.internal("blueCircle.png"));
		yellowCircleTexture = new Texture(Gdx.files.internal("yellowCircle.png"));
		
		mapTileTiled = new TiledDrawable(new TextureRegion(mapTileTexture));
		mapWrapperTiled = new TiledDrawable(new TextureRegion(mapWrapperTexture));
		mapNotPlainTiled = new TiledDrawable(new TextureRegion(mapNotPlainTexture));
	}
	
	public static void dispose(){
		bgTexture.dispose();
		mapTileTexture.dispose();
		mapNotPlainTexture.dispose();
		mapWrapperTexture.dispose();
		playerTexture.dispose();
		blueCircleTexture.dispose();
		yellowCircleTexture.dispose();
	}
}
